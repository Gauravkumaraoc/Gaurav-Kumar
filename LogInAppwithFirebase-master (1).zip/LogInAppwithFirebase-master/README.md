# LogInAppwithFirebase
this is angularjs log app with firebase
